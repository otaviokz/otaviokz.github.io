import os

def run_in_test_environment():
    os.environ['ENVIRONEMTNT'] = 'TEST'

def run_in_debug_environment():
    os.environ['ENVIRONEMTNT'] = 'DEBUG'

def run_in_production_environment():
    os.environ['ENVIRONEMTNT'] = 'PRODUCTION'