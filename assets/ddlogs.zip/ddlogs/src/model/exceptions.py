class InvalidLogEntry(Exception):
    def init(self, message: str):
        self.message = message

class InvalidDate(Exception):
    def init(self, date: str):
        self.message = f"Invalid date: [{date}]"