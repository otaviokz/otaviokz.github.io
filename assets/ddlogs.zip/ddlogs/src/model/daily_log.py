from exceptions import InvalidLogEntry, InvalidDate
from date_validator import validate_date_string
from action import Action


class DailyLog:
    def __init__(self,date=str):
        if not validate_date_string(date):
            raise InvalidDate(date)
        self.date = date
        self.notes = []
        self.currents = []
        self.actions = [Action]        
        self.communications = []
        self.moods = []
        self.others = []


    def add_note(self, note: str):
        if len(note) >= 3 and not note in self.notes:
            self.notes.append(note)
        else:
            raise InvalidLogEntry(f"Invalid note: [{note}]")


    def add_current(self, current: str):
        if len(current) >= 3 and not current in self.current:
            self.currents.append(current)
        else:
            raise InvalidLogEntry(f"Invalid or repeated current: [{current}]")


    def add_action(self, action: Action):
        if action in self.actions:
            raise InvalidLogEntry(f"Repeated action: [{action.action}]")
        else:
            self.actions.append(action)


    def add_communication(self, communication: str):
        if len(communication) >= 3 and not communication in self.communications:
            self.communications.append(communication)
        else:
            raise InvalidLogEntry(f"Invalid or repeated communication: [{communication}]")


    def add_mood(self, mood: str):
        if len(mood) >= 3 and not mood in self.moods:
            self.moods.append(mood)
        else:
            raise InvalidLogEntry(f"Invalid or repeated mood: [{mood}]")


    def add_other(self, other: str):
        if len(other) >= 3 and not other in self.others:
            self.others.append(other)
        else:
            raise InvalidLogEntry(f"Invalid or repeated other: [{other}]")
        