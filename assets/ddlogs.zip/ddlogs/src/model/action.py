from date_validator import validate_date_string
from exceptions import InvalidDate


class Action:
    def __init__(self, action: str, deadline_date: str):
        if not validate_date_string(deadline_date):
            raise InvalidDate(deadline_date)
        
        self.action = action
        self.deadline_date = deadline_date