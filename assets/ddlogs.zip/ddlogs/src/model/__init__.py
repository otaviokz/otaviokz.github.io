import sys
sys.path.append('../src/validators')
sys.path.append('../src/model')
sys.path.append('../src/database')
sys.path.append('..')
