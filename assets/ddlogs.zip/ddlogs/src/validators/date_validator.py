import re
DATE_REGEX = r"\b(0[1-9]|[12]\d|3[01])[/](0[1-9]|1[0-2])[/](19\d\d|20\d\d)\b"
THIRTY_DAY_MONTHS = [4, 6, 9, 11]
REFERENCE_LEAP_YEAR = 2024


def validate_date_string(date: str):
    matches_regex = re.match(DATE_REGEX, date) is not None
    if matches_regex:
        numbers = date.split("/")
        day = int(numbers[0])
        month = int(numbers[1])
        year = int(numbers[2])

        if month == 2 and day > 29:
            return False
        elif month == 2 and day == 29:
            return is_leap_year(year)
        elif day == 31:
            return month not in THIRTY_DAY_MONTHS
        else:
            return True
    else:
        return False


def is_leap_year(year: int):
    return ((year - REFERENCE_LEAP_YEAR) % 4) == 0