import pymongo
import os 
from daily_log import DailyLog

def environmentDatabase():
    environment = os.environ['ENVIRONMENT'] 
    if environment == 'PRODUCTION':
        return 'prod_db'
    elif environment == 'DEBUG':
        return 'debug_db'
    else:
        return 'test_db'




def insert_daily_log(daily_log):
    myclient = pymongo.MongoClient("mongodb://localhost:27017/")
    mydb = myclient[environmentDatabase()]
    daily_logs_col = mydb["daily_logs"]
    daily_logs_col.insert_one(daily_log.__dict__)
