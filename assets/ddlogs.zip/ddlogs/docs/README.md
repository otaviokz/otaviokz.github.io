# ⏳ DDLOG 

This peoject is meant as a frugal daily journal for may activities as a software developer.

The current idea is recording daily data divided in a small numer of lists categorised as:
<ul>
<li><span style="font-weight:bold">CURRENT: </span>current tasks and activities I'm working on, technologies I'm using, time spent on them, if required by client, blocks etc.</li></p>

<li><span style="font-weight:bold">NOTES: </span>Significative facts and ocurrences that may be util to remember later on, like technical decisions, why some task got blocked, etc.</li></p>

<li><span style="font-weight:bold">ACTIONS: </span> actions I'll need to take in response to some entry on <span style="font-weight:bold">CURRENT</spam> or <span style="font-weight:bold">NOTES</spam> from this or another day's logs.</li></p>

<li><span style="font-weight:bold">COMMUNICATION: </span>Information that should be communicated in the next standup meeting, to bring visibility to anything important, problematic, or simply reminding management of a couple of awesome things I've achieved or overcame in the previous day(s) - <span style="font-style:italic;font-weight:bold">"quality only exists when perceived"</span>.</li></p>
<li><span style="font-weight:bold">MOOD:</span> How am I feeling about things in, be it in general or about something specific.</li>
</p>
<li><span style="font-weight:bold">OTHER:</span> Thought's, ideas, feelings, impressions, funny things that happened.</li>
Such data would be grouped under date, and possibly linked to current job/client/employer/project etc.