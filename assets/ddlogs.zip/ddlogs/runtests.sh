export ENVIRONMENT=TEST
cd tests;
pytest;