from client import insert_daily_log
from daily_log import DailyLog
from run_environments import run_in_test_environment
# from model import DailyLog

def test_insert_daily_log():
    run_in_test_environment()
    daily_log = DailyLog('31/12/2024')
    insert_daily_log(daily_log)