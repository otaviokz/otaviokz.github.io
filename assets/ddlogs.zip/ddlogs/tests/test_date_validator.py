from date_validator import validate_date_string # type: ignore

# THIRTY_DAY_MONTHS = [4, 6, 9, 11]
# REFERENCE_LEAP_YEAR = 2024

def test_validate_valid_dates():
    assert validate_date_string("25/12/2024")
    assert validate_date_string("15/01/2024")
    assert validate_date_string("01/01/2000")


def test_check_total_month_days_when_validating():
    assert validate_date_string("31/01/2025")
    assert validate_date_string("31/03/2025")
    assert not validate_date_string("31/04/2025")
    assert validate_date_string("31/05/2025")
    assert not validate_date_string("31/06/2025")
    assert validate_date_string("31/07/2025")
    assert validate_date_string("31/08/2025")
    assert not validate_date_string("31/09/2025")
    assert validate_date_string("31/10/2025")
    assert not validate_date_string("31/11/2025")
    assert validate_date_string("31/12/2025")


def test_validate_29_february_only_in_leap_years():
    assert validate_date_string("29/02/2024")
    assert not validate_date_string("29/02/2029")
    assert validate_date_string("29/02/2032")
    assert not validate_date_string("29/02/2035")
    assert validate_date_string("29/02/2040")
